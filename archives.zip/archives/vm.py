# create wallet, check if wallet already exist, if yes error else create
# add money
# send money
# balance


# crud create read [update delete]
class vm:
    pass
