function Initialize-Folder {
    param (
        [string]$FolderPath,
        [string]$ProjectName
    )

    # Check if the folder exists, if not create it
    if (-not (Test-Path -Path $FolderPath)) {
        New-Item -ItemType Directory -Path $FolderPath
        Write-Output "Created folder: $FolderPath"
    } else {
        Write-Output "Folder already exists: $FolderPath"
    }

    # Create README.md with sections
    $readmeContent = @"
# $ProjectName

## Description

## Tasks

## Notes
"@
    $readmePath = Join-Path -Path $FolderPath -ChildPath "README.md"
    Set-Content -Path $readmePath -Value $readmeContent
    Write-Output "Created README.md with project title"

    # Create Archives, Home, Favorites folders with project name
    $folders = @("Archives_$ProjectName", "Home_$ProjectName", "Favorites_$ProjectName")
    foreach ($folder in $folders) {
        $NewFolderPath = Join-Path -Path $FolderPath -ChildPath $folder
        if (-not (Test-Path -Path $NewFolderPath)) {
            New-Item -ItemType Directory -Path $NewFolderPath
            Write-Output "Created folder: $folder"
        } else {
            Write-Output "Folder already exists: $folder"
        }
    }

    # Create .gitignore
    $gitignoreContent = @"
# Ignore node_modules folder
node_modules/

# Ignore logs and temporary files
*.log
*.tmp

# Ignore IDE-specific files
.vscode/
.idea/
"@
    $gitignorePath = Join-Path -Path $FolderPath -ChildPath ".gitignore"
    Set-Content -Path $gitignorePath -Value $gitignoreContent
    Write-Output "Created .gitignore"
}

# Example usage
#Initialize-Folder -FolderPath ".\PRJCT1" -ProjectName "PRJCT1"
