#smart contracts
#If and then staments
# scan trhough block chain and update register  and based on the register values chake if conditions id satisfied 
# when condition is setisfied create a transaction coreesponding to contract validate transection and mine block


# tables or databases
# user registration
# block chain
# transection
# smart contracts
# register current state
# wallets
# dao
# dapps
# vm
# mine


# example smart contract every 10 th miner will get bonus +! coin
# checck curent mining block if it 10 create transection to add +1 coint to user who has mined it
# user gets publik and private keys
# utility fuctions hash, signature, mine, mnemonics, passprase


