
---

type: notes
created: 06-11-2024

---

## Ideas in between:

- [ ] create a decentralized university 
- [ ]  different init for private folder such AS notes and personal work
      - Different Readme (Title, Description, Tasks, Notes)
      - Archives, Home, Favorites folder (AHF)
      - .gitignore
